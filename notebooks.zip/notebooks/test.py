# Databricks notebook source
display(dbutils.fs.ls("dbfs:/code/"))
display(dbutils.fs.ls("dbfs:/configs/"))


# COMMAND ----------

# Sanity import
import types
helpers_text = dbutils.fs.head("dbfs:/code/_utils.py", 10_000_000)
_utils = types.ModuleType("_utils")
exec(compile(helpers_text, "dbfs:/code/_utils.py", "exec"), _utils.__dict__)



# COMMAND ----------

cfg = _utils.load_config("dbfs:/configs/etl_config.json")
print(cfg.keys())