# Databricks notebook source
# ============================================================
# GOLD – KPI FACT + BI VIEW
# Author: Vedanti Awaghade
#
# What this does:
# 1) Reads Silver (row-level, valid-only with record_id).
# 2) Aggregates to a business grain (month, format, device_type, bid_type, network_id).
# 3) Calculates KPIs:
#       - CPM = spend / impressions * 1000
#       - CPE = spend / engagements
#       - CTR = clicks / impressions
#       - Viewability = viewable_imps / measurable_imps
#       - Engagement Rate = engagements / clicks
#       - VCR = video_complete / video_start
#       - ACR = audio_complete / audio_start
# 4) Writes a fresh Gold table (overwrite latest snapshot).
# 5) Creates/updates a BI view that is easy for Power BI to consume.
# 6) (Optional) Saves a partitioned snapshot to GCS for backup/audits.
# ============================================================

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timezone
import json

# ---------- Run stamp (consistent across notebooks if set) ----------
dbutils.widgets.text("run_ts", "")
try:
    RUN_TS = dbutils.widgets.get("run_ts") or spark.conf.get("dsp.run_ts")
except Exception:
    RUN_TS = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    spark.conf.set("dsp.run_ts", RUN_TS)

# ---------- Load config ----------
config       = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG      = config["catalog"]
SILVER_TABLE = config["silver_table"]
GOLD_TABLE   = config["gold_table"]
BI_VIEW      = config["bi_view"]
SNAPSHOT_GCS = config.get("snapshot_path")  # optional

spark.sql(f"USE CATALOG {CATALOG}")

print(f"Gold run         → {RUN_TS}")
print(f"Source (Silver)  → {SILVER_TABLE}")
print(f"Target (Gold)    → {GOLD_TABLE}")
print(f"BI view          → {BI_VIEW}")

# ============================================================
# 0) Read Silver
# ============================================================
dfs = spark.read.table(SILVER_TABLE)

# Guard: required numeric cols present
needed = {
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete"
}
missing = needed - set(dfs.columns)
if missing:
    raise ValueError(f"Silver is missing required columns: {sorted(list(missing))}")

# ============================================================
# 1) Aggregate to business grain
#    (month, format, device_type, bid_type, network_id)
# ============================================================
grain = ["month","format","device_type","bid_type","network_id"]

df_agg = (
    dfs.groupBy(grain)
       .agg(
           F.sum("spend").alias("spend"),
           F.sum("impressions").alias("impressions"),
           F.sum("clicks").alias("clicks"),
           F.sum("measurable_imps").alias("measurable_imps"),
           F.sum("viewable_imps").alias("viewable_imps"),
           F.sum("engagements").alias("engagements"),
           F.sum("video_start").alias("video_start"),
           F.sum("video_complete").alias("video_complete"),
           F.sum("audio_start").alias("audio_start"),
           F.sum("audio_complete").alias("audio_complete")
       )
)

# ============================================================
# 2) KPI calculations (null/zero safe)
#    Using safe divisions to avoid NaN/Inf.
# ============================================================
def safe_div(n, d):
    return F.when((d.isNull()) | (d == 0), F.lit(None).cast("double")).otherwise(n / d)

df_gold = (
    df_agg
      .withColumn("cpm",  safe_div(F.col("spend"), F.col("impressions")) * F.lit(1000.0))
      .withColumn("cpe",  safe_div(F.col("spend"), F.col("engagements")))
      .withColumn("ctr",  safe_div(F.col("clicks"), F.col("impressions")))
      .withColumn("viewability",     safe_div(F.col("viewable_imps"), F.col("measurable_imps")))
      .withColumn("engagement_rate", safe_div(F.col("engagements"), F.col("clicks")))
      .withColumn("vcr",  safe_div(F.col("video_complete"), F.col("video_start")))
      .withColumn("acr",  safe_div(F.col("audio_complete"), F.col("audio_start")))
      .withColumn("gold_ingest_ts", F.current_timestamp())
      .withColumn("gold_run_ts", F.lit(RUN_TS))
)

# Optional: round KPIs for reporting neatness (keep raw in separate table if you need full precision)
for k in ["cpm","cpe","ctr","viewability","engagement_rate","vcr","acr"]:
    df_gold = df_gold.withColumn(k, F.round(F.col(k), 6))

# Column order (nice for BI)
ordered = grain + [
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete",
    "cpm","cpe","ctr","viewability","engagement_rate","vcr","acr",
    "gold_ingest_ts","gold_run_ts"
]
df_gold = df_gold.select(*ordered)

# ============================================================
# 3) Write/replace Gold table (latest-only snapshot)
# ============================================================
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")
spark.sql(f"DROP TABLE IF EXISTS {GOLD_TABLE}")
df_gold.write.mode("overwrite").saveAsTable(GOLD_TABLE)

print(f"✅ Gold table refreshed: {GOLD_TABLE}")
display(df_gold.limit(10))

# ============================================================
# 4) Create / Replace BI View (thin layer for Power BI)
#    Keeps field names business-friendly and exposes KPIs.
# ============================================================
spark.sql(f"""
CREATE OR REPLACE VIEW {BI_VIEW} AS
SELECT
  month,
  format,
  --record_id,
  device_type,
  bid_type,
  network_id,
  spend,
  impressions,
  clicks,
  measurable_imps,
  viewable_imps,
  engagements,
  video_start,
  video_complete,
  audio_start,
  audio_complete,
  cpm,
  cpe,
  ctr,
  viewability,
  engagement_rate,
  vcr,
  acr,
  gold_ingest_ts,
  gold_run_ts,
  current_timestamp() AS bi_view_created_ts,  -- 🔹 New: BI view creation timestamp
    current_date() AS bi_view_created_date  
FROM {GOLD_TABLE}
""")

print(f"✅ BI view created/updated: {BI_VIEW}")

# ============================================================
# 5) Optional: write a snapshot to GCS for audit/backup
#    This writes partitioned by month for easy retrieval.
# ============================================================
if SNAPSHOT_GCS:
    out = SNAPSHOT_GCS.rstrip("/")
    (df_gold
        .repartition("month")
        .write
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .format("delta")
        .partitionBy("month")
        .save(out))
    print(f"🧷 Snapshot written to: {out}")


# COMMAND ----------

# ============================================================
# 03_gold_metric_run
# Author: Vedanti Awaghade
#
# Purpose of this notebook in the pipeline job:
# 1. Recreate the BI view for Power BI from the latest Gold table.
# 2. Capture lineage / freshness / rowcount for governance.
# 3. Append that metadata into an audit Delta table.
#
# This gives marketing + analytics:
#   - a clean semantic view (vw_campaign_summary)
#   - proof of "when/who/with what data" the view was refreshed
# ============================================================

from pyspark.sql import functions as F
from datetime import datetime, timezone
import json

# ------------------------------------------------------------
# 0. Load config and set catalog
# ------------------------------------------------------------
config       = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG      = config["catalog"]
GOLD_TABLE   = config["gold_table"]     # e.g. databricks_gcp_mars_powerbi.analytics.fact_campaign_performance
BI_VIEW      = config["bi_view"]        # e.g. databricks_gcp_mars_powerbi.analytics.vw_campaign_summary

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")

# ------------------------------------------------------------
# 1. Ensure RUN_TS / RUN_ID exist (either from controller or fallback)
# ------------------------------------------------------------
try:
    RUN_TS = spark.conf.get("dsp.run_ts")
except Exception:
    RUN_TS = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    spark.conf.set("dsp.run_ts", RUN_TS)

try:
    RUN_ID = spark.conf.get("dsp.run_id")
except Exception:
    RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    spark.conf.set("dsp.run_id", RUN_ID)

# ------------------------------------------------------------
# 2. Rebuild the BI view from Gold
#    NOTE: We do NOT include record_id here, because Gold is aggregated.
# ------------------------------------------------------------
spark.sql(f"""
CREATE OR REPLACE VIEW {BI_VIEW} AS
SELECT
  month,
  format,
  device_type,
  bid_type,
  network_id,
  spend,
  impressions,
  clicks,
  measurable_imps,
  viewable_imps,
  engagements,
  video_start,
  video_complete,
  audio_start,
  audio_complete,
  cpm,
  cpe,
  ctr,
  viewability,
  engagement_rate,
  vcr,
  acr,
  gold_ingest_ts,
  gold_run_ts,
  current_timestamp() AS bi_view_created_ts,
  current_date()      AS bi_view_created_date
FROM {GOLD_TABLE}
""")

spark.sql(f"""
COMMENT ON VIEW {BI_VIEW} IS
'Business-facing summary for Power BI. Auto-refreshed from Gold with freshness + run metadata.'
""")

# ------------------------------------------------------------
# 3. Prepare the audit table name and create it if missing
# ------------------------------------------------------------
AUDIT_TABLE = f"{CATALOG}.analytics.bi_metadata_audit"

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {AUDIT_TABLE} (
  bi_view_name      STRING,
  created_ts        TIMESTAMP,
  created_date      DATE,
  created_by        STRING,
  source_table      STRING,
  source_catalog    STRING,
  source_schema     STRING,
  run_ts            STRING,
  run_id            STRING,
  gold_last_run_ts  TIMESTAMP,
  gold_last_ingest  TIMESTAMP,
  gold_row_count    BIGINT,
  note              STRING
) USING DELTA
COMMENT 'Audit log of BI view refresh events for governance and SLA tracking.'
""")

# ------------------------------------------------------------
# 4. Collect Gold stats for traceability
#    - latest gold_run_ts / gold_ingest_ts
#    - row count
# ------------------------------------------------------------
df_gold = spark.read.table(GOLD_TABLE)

gold_row_count = df_gold.count()
if gold_row_count == 0:
    gold_last_run_ts = None
    gold_last_ingest = None
else:
    gold_stats = (
        df_gold
        .agg(
            F.max("gold_run_ts").alias("max_run_ts"),
            F.max("gold_ingest_ts").alias("max_ingest_ts")
        )
        .collect()[0]
    )
    gold_last_run_ts = gold_stats["max_run_ts"]
    gold_last_ingest = gold_stats["max_ingest_ts"]

# ------------------------------------------------------------
# 5. Gather runtime context (who ran it, what catalog/schema we're in)
# ------------------------------------------------------------
who         = spark.sql("SELECT current_user()").collect()[0][0]
cur_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
cur_schema  = spark.sql("SELECT current_schema()").collect()[0][0]

now_dt     = datetime.now(timezone.utc)
created_dt = now_dt.date()

# ------------------------------------------------------------
# 6. Build the audit row as a small DataFrame
#    We'll infer, then cast and order to match the audit table schema.
# ------------------------------------------------------------
audit_raw_df = spark.createDataFrame([
    {
        "bi_view_name":     BI_VIEW,
        "created_ts":       now_dt,              # timestamp aware
        "created_date":     created_dt,          # date
        "created_by":       who,
        "source_table":     GOLD_TABLE,
        "source_catalog":   cur_catalog,
        "source_schema":    cur_schema,
        "run_ts":           RUN_TS,
        "run_id":           RUN_ID,
        "gold_last_run_ts": gold_last_run_ts,
        "gold_last_ingest": gold_last_ingest,
        "gold_row_count":   int(gold_row_count),
        "note":             "BI view refreshed from job"
    }
])

audit_df = (
    audit_raw_df
    .select(
        F.col("bi_view_name").cast("string"),
        F.col("created_ts").cast("timestamp"),
        F.col("created_date").cast("date"),
        F.col("created_by").cast("string"),
        F.col("source_table").cast("string"),
        F.col("source_catalog").cast("string"),
        F.col("source_schema").cast("string"),
        F.col("run_ts").cast("string"),
        F.col("run_id").cast("string"),
        F.col("gold_last_run_ts").cast("timestamp"),
        F.col("gold_last_ingest").cast("timestamp"),
        F.col("gold_row_count").cast("bigint"),
        F.col("note").cast("string")
    )
)

# ------------------------------------------------------------
# 7. Append audit event to Delta table
# ------------------------------------------------------------
audit_df.write.mode("append").saveAsTable(AUDIT_TABLE)

print(f"✅ BI view refreshed → {BI_VIEW}")
print(f"🧾 Audit appended   → {AUDIT_TABLE}")
print(
    f"   gold_row_count={gold_row_count:,}  "
    f"gold_last_run_ts={gold_last_run_ts}  "
    f"run_id={RUN_ID}"
)


# COMMAND ----------

# MAGIC %md
# MAGIC from datetime import datetime, timezone
# MAGIC from pyspark.sql import functions as F
# MAGIC
# MAGIC # --- Ensure run variables exist even if not set by controller ---
# MAGIC try:
# MAGIC     RUN_TS = spark.conf.get("dsp.run_ts")
# MAGIC except Exception:
# MAGIC     RUN_TS = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
# MAGIC     spark.conf.set("dsp.run_ts", RUN_TS)
# MAGIC
# MAGIC try:
# MAGIC     RUN_ID = spark.conf.get("dsp.run_id")
# MAGIC except Exception:
# MAGIC     RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
# MAGIC     spark.conf.set("dsp.run_id", RUN_ID)
# MAGIC
# MAGIC # --- Who/where info ---
# MAGIC who         = spark.sql("SELECT current_user()").collect()[0][0]
# MAGIC cur_catalog = spark.sql("SELECT current_catalog()").collect()[0][0]
# MAGIC cur_schema  = spark.sql("SELECT current_schema()").collect()[0][0]
# MAGIC
# MAGIC now_dt     = datetime.now(timezone.utc)
# MAGIC created_dt = now_dt.date()
# MAGIC
# MAGIC # --- Build the record (Spark infers schema) ---
# MAGIC audit_raw_df = spark.createDataFrame([
# MAGIC     {
# MAGIC         "bi_view_name":     BI_VIEW,
# MAGIC         "created_ts":       now_dt,
# MAGIC         "created_date":     created_dt,
# MAGIC         "created_by":       who,
# MAGIC         "source_table":     GOLD_TABLE,
# MAGIC         "source_catalog":   cur_catalog,
# MAGIC         "source_schema":    cur_schema,
# MAGIC         "run_ts":           RUN_TS,
# MAGIC         "run_id":           RUN_ID,
# MAGIC         "gold_last_run_ts": gold_last_run_ts,
# MAGIC         "gold_last_ingest": gold_last_ingest,
# MAGIC         "gold_row_count":   int(gold_row_count),
# MAGIC         "note":             "BI view refreshed from job"
# MAGIC     }
# MAGIC ])
# MAGIC
# MAGIC # --- Cast & reorder to match audit table exactly ---
# MAGIC audit_df = (
# MAGIC     audit_raw_df.select(
# MAGIC         F.col("bi_view_name").cast("string"),
# MAGIC         F.col("created_ts").cast("timestamp"),
# MAGIC         F.col("created_date").cast("date"),
# MAGIC         F.col("created_by").cast("string"),
# MAGIC         F.col("source_table").cast("string"),
# MAGIC         F.col("source_catalog").cast("string"),
# MAGIC         F.col("source_schema").cast("string"),
# MAGIC         F.col("run_ts").cast("string"),
# MAGIC         F.col("run_id").cast("string"),
# MAGIC         F.col("gold_last_run_ts").cast("timestamp"),
# MAGIC         F.col("gold_last_ingest").cast("timestamp"),
# MAGIC         F.col("gold_row_count").cast("bigint"),
# MAGIC         F.col("note").cast("string")
# MAGIC     )
# MAGIC )
# MAGIC
# MAGIC # --- Append to the Delta audit table ---
# MAGIC audit_df.write.mode("append").saveAsTable(AUDIT_TABLE)
# MAGIC
# MAGIC print(f"✅ BI view refreshed → {BI_VIEW}")
# MAGIC print(f"🧾 Audit appended   → {AUDIT_TABLE}")
# MAGIC print(f"   gold_row_count={gold_row_count:,}  gold_last_run_ts={gold_last_run_ts}  run_id={RUN_ID}")
# MAGIC