# Databricks notebook source
# MAGIC %md
# MAGIC # ============================================================
# MAGIC # GOLD VALIDATION — fact & KPI quality checks
# MAGIC # Author: Vedanti Awaghade
# MAGIC #
# MAGIC # What I’m checking:
# MAGIC #  0) Tables/views exist (Silver, Gold, BI view)
# MAGIC #  1) Freshness (gold_ingest_ts) and basic row count
# MAGIC #  2) Required columns present (measures + KPIs)
# MAGIC #  3) KPI sanity/bounds (>=0, ratios in [0,1], no NaN/Inf)
# MAGIC #  4) Recompute from Silver and reconcile with Gold (within tolerance)
# MAGIC #  5) Print a clean summary + alerts
# MAGIC # ============================================================
# MAGIC
# MAGIC from pyspark.sql import functions as F
# MAGIC from pyspark.sql import types as T
# MAGIC from datetime import datetime, timedelta
# MAGIC import json
# MAGIC import math
# MAGIC
# MAGIC # ---------------------------
# MAGIC # Config & constants
# MAGIC # ---------------------------
# MAGIC config        = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
# MAGIC CATALOG       = config["catalog"]
# MAGIC SILVER_TABLE  = config["silver_table"]
# MAGIC GOLD_TABLE    = config["gold_table"]
# MAGIC BI_VIEW       = config["bi_view"]
# MAGIC
# MAGIC spark.sql(f"USE CATALOG {CATALOG}")
# MAGIC
# MAGIC TOL   = 1e-6    # numeric reconciliation tolerance
# MAGIC FRESH = 6       # hours; flag if gold is older than this
# MAGIC
# MAGIC # Optional: scope validation to a month or range
# MAGIC # dbutils.widgets.text("month_filter", "")     # e.g., "2023-08-01"
# MAGIC # MONTH_FILTER = dbutils.widgets.get("month_filter").strip()
# MAGIC
# MAGIC # ---------------------------
# MAGIC # Helpers
# MAGIC # ---------------------------
# MAGIC def table_exists(name: str) -> bool:
# MAGIC     try:
# MAGIC         return spark.catalog.tableExists(name)
# MAGIC     except Exception:
# MAGIC         return False
# MAGIC
# MAGIC def view_exists(name: str) -> bool:
# MAGIC     try:
# MAGIC         spark.table(name)
# MAGIC         return True
# MAGIC     except Exception:
# MAGIC         return False
# MAGIC
# MAGIC def ratio_in_01(col):
# MAGIC     return (F.col(col) >= 0) & (F.col(col) <= 1)
# MAGIC
# MAGIC # ---------------------------
# MAGIC # 0) Existence
# MAGIC # ---------------------------
# MAGIC issues = []
# MAGIC if not table_exists(SILVER_TABLE): issues.append(f"Missing Silver: {SILVER_TABLE}")
# MAGIC if not table_exists(GOLD_TABLE):   issues.append(f"Missing Gold: {GOLD_TABLE}")
# MAGIC if not view_exists(BI_VIEW):       issues.append(f"Missing BI view: {BI_VIEW}")
# MAGIC
# MAGIC if issues:
# MAGIC     print("❌ Validation halted — required object(s) missing:")
# MAGIC     for i in issues: print("  •", i)
# MAGIC     raise SystemExit
# MAGIC
# MAGIC # ---------------------------
# MAGIC # Load data (optionally filter by month)
# MAGIC # ---------------------------
# MAGIC dfs = spark.read.table(SILVER_TABLE)
# MAGIC dfg = spark.read.table(GOLD_TABLE)
# MAGIC
# MAGIC # if MONTH_FILTER:
# MAGIC #     dfs = dfs.filter(F.col("month") == F.to_date(F.lit(MONTH_FILTER)))
# MAGIC #     dfg = dfg.filter(F.col("month") == F.to_date(F.lit(MONTH_FILTER)))
# MAGIC
# MAGIC # ---------------------------
# MAGIC # 1) Freshness & counts
# MAGIC # ---------------------------
# MAGIC gold_cnt = dfg.count()
# MAGIC max_g_ts = dfg.agg(F.max("gold_ingest_ts")).first()[0]
# MAGIC fresh_min = None
# MAGIC if max_g_ts:
# MAGIC     fresh_min = (datetime.now(timezone.utc) - max_g_ts).total_seconds()/60
# MAGIC
# MAGIC print(f"Gold rows: {gold_cnt:,}")
# MAGIC print(f"Gold max(gold_ingest_ts): {max_g_ts}  (~{round(fresh_min,1) if fresh_min is not None else 'NA'} min ago)")
# MAGIC
# MAGIC # ---------------------------
# MAGIC # 2) Required columns
# MAGIC # ---------------------------
# MAGIC req_measures = {
# MAGIC     "spend","impressions","clicks","measurable_imps","viewable_imps",
# MAGIC     "engagements","video_start","video_complete","audio_start","audio_complete"
# MAGIC }
# MAGIC req_kpis = {"cpm","cpe","ctr","viewability","engagement_rate","vcr","acr","gold_ingest_ts","gold_run_ts"}
# MAGIC req_dims = {"month","format","device_type","bid_type","network_id"}
# MAGIC
# MAGIC missing_cols = (req_measures | req_kpis | req_dims) - set(dfg.columns)
# MAGIC if missing_cols:
# MAGIC     issues.append(f"Gold missing columns: {sorted(missing_cols)}")
# MAGIC
# MAGIC # ---------------------------
# MAGIC # 3) KPI sanity checks
# MAGIC # ---------------------------
# MAGIC kpi_bounds = {
# MAGIC     "cpm": (0, None),           # >= 0
# MAGIC     "cpe": (0, None),           # >= 0 (can be None if engagements = 0)
# MAGIC     "ctr": (0, 1),              # [0,1]
# MAGIC     "viewability": (0, 1),      # [0,1]
# MAGIC     "engagement_rate": (0, None),  # >= 0 (can exceed 1 if engagements>clicks in some defs; we just require non-negative)
# MAGIC     "vcr": (0, 1),              # [0,1]
# MAGIC     "acr": (0, 1)               # [0,1]
# MAGIC }
# MAGIC kpi_violations = {}
# MAGIC for k, (lo, hi) in kpi_bounds.items():
# MAGIC     if k in dfg.columns:
# MAGIC         cond = (F.col(k) < lo) | (F.isnan(k)) | (F.col(k).isNull())
# MAGIC         if hi is not None:
# MAGIC             cond = cond | (F.col(k) > hi)
# MAGIC         cnt = dfg.filter(cond).count()
# MAGIC         if cnt > 0:
# MAGIC             kpi_violations[k] = cnt
# MAGIC
# MAGIC # ---------------------------
# MAGIC # 4) Recompute from Silver and reconcile with Gold
# MAGIC # ---------------------------
# MAGIC grain = ["month","format","device_type","bid_type","network_id"]
# MAGIC
# MAGIC # Sum Silver to the Gold grain
# MAGIC dfs_agg = (
# MAGIC     dfs.groupBy(grain)
# MAGIC        .agg(
# MAGIC            F.sum("spend").alias("spend"),
# MAGIC            F.sum("impressions").alias("impressions"),
# MAGIC            F.sum("clicks").alias("clicks"),
# MAGIC            F.sum("measurable_imps").alias("measurable_imps"),
# MAGIC            F.sum("viewable_imps").alias("viewable_imps"),
# MAGIC            F.sum("engagements").alias("engagements"),
# MAGIC            F.sum("video_start").alias("video_start"),
# MAGIC            F.sum("video_complete").alias("video_complete"),
# MAGIC            F.sum("audio_start").alias("audio_start"),
# MAGIC            F.sum("audio_complete").alias("audio_complete")
# MAGIC        )
# MAGIC )
# MAGIC
# MAGIC # Compute KPIs safely (same formulas as Gold)
# MAGIC def safe_div(n, d):
# MAGIC     return F.when((d.isNull()) | (d == 0), F.lit(None).cast("double")).otherwise(n / d)
# MAGIC
# MAGIC dfs_chk = (
# MAGIC     dfs_agg
# MAGIC       .withColumn("cpm",  safe_div(F.col("spend"), F.col("impressions")) * F.lit(1000.0))
# MAGIC       .withColumn("cpe",  safe_div(F.col("spend"), F.col("engagements")))
# MAGIC       .withColumn("ctr",  safe_div(F.col("clicks"), F.col("impressions")))
# MAGIC       .withColumn("viewability",     safe_div(F.col("viewable_imps"), F.col("measurable_imps")))
# MAGIC       .withColumn("engagement_rate", safe_div(F.col("engagements"), F.col("clicks")))
# MAGIC       .withColumn("vcr",  safe_div(F.col("video_complete"), F.col("video_start")))
# MAGIC       .withColumn("acr",  safe_div(F.col("audio_complete"), F.col("audio_start")))
# MAGIC )
# MAGIC
# MAGIC # Join with Gold and compare numeric columns
# MAGIC join_cols = grain
# MAGIC compare_cols = list(req_measures | {"cpm","cpe","ctr","viewability","engagement_rate","vcr","acr"})
# MAGIC present = [c for c in compare_cols if c in dfg.columns and c in dfs_chk.columns]
# MAGIC
# MAGIC df_join = (
# MAGIC     dfg.alias("g").join(dfs_chk.alias("s"), on=join_cols, how="full")
# MAGIC )
# MAGIC
# MAGIC # For each numeric col, compute abs diff and flag above tolerance
# MAGIC recon = {}
# MAGIC for c in present:
# MAGIC     diff_col = F.abs(F.col(f"g.{c}") - F.col(f"s.{c}"))
# MAGIC     cnt_over = df_join.filter(diff_col > TOL).count()
# MAGIC     if cnt_over > 0:
# MAGIC         recon[c] = cnt_over
# MAGIC
# MAGIC # Also check for unmatched keys (present in one side but not the other)
# MAGIC only_gold = df_join.filter(
# MAGIC     F.col("g.month").isNotNull() & F.col("s.month").isNull()
# MAGIC ).count()
# MAGIC only_silver = df_join.filter(
# MAGIC     F.col("s.month").isNotNull() & F.col("g.month").isNull()
# MAGIC ).count()
# MAGIC
# MAGIC # ---------------------------
# MAGIC # 5) Summary + Alerts
# MAGIC # ---------------------------
# MAGIC print("\n=== GOLD VALIDATION SUMMARY ==========================")
# MAGIC print(f"• Missing columns          : {sorted(missing_cols) if missing_cols else 'None'}")
# MAGIC print(f"• KPI bound violations     : {kpi_violations if kpi_violations else 'None'}")
# MAGIC print(f"• Unmatched keys           : only_gold={only_gold:,}, only_silver={only_silver:,}")
# MAGIC print(f"• Reconciliation diffs (> {TOL}): {recon if recon else 'None'}")
# MAGIC
# MAGIC alerts = []
# MAGIC if fresh_min is not None and fresh_min > FRESH*60:
# MAGIC     alerts.append(f"Gold looks stale (> {FRESH}h): ~{round(fresh_min/60,2)}h")
# MAGIC if missing_cols:
# MAGIC     alerts.append("Gold is missing required columns.")
# MAGIC if kpi_violations:
# MAGIC     alerts.append("Some KPIs are out of expected bounds or null/NaN.")
# MAGIC if only_gold or only_silver:
# MAGIC     alerts.append("Gold/Silver have unmatched groups at the reporting grain.")
# MAGIC if recon:
# MAGIC     alerts.append("Gold and recomputed-from-Silver don’t match within tolerance.")
# MAGIC
# MAGIC if alerts:
# MAGIC     print("\n⚠️  ALERTS:")
# MAGIC     for a in alerts:
# MAGIC         print("   •", a)
# MAGIC else:
# MAGIC     print("\n✅ Gold validation passed the main checks.")
# MAGIC
# MAGIC # ---------------------------
# MAGIC # Optional: show a few suspect rows for any recon diff
# MAGIC # ---------------------------
# MAGIC if recon or only_gold or only_silver:
# MAGIC     suspect_cols = [c for c, n in recon.items() if n > 0]
# MAGIC     show_cols = grain + suspect_cols
# MAGIC     print("\nExample suspect rows (first 20):")
# MAGIC     display(
# MAGIC         df_join
# MAGIC           .select(*( [F.col(f"g.{c}").alias(c) for c in show_cols] +
# MAGIC                      [F.col(f"s.{c}").alias(f"{c}_recalc") for c in suspect_cols] ))
# MAGIC           .where(
# MAGIC               (F.col("g.month").isNull()) | (F.col("s.month").isNull()) |
# MAGIC               F.lit(True).isin([False])  # placeholder to allow OR’ing diffs below
# MAGIC           )
# MAGIC           .limit(20)
# MAGIC     )
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC # ============================================================
# MAGIC # BI VIEW + GOVERNANCE AUDIT
# MAGIC # Author: Vedanti Awaghade
# MAGIC #
# MAGIC # What this does:
# MAGIC # 1) Rebuilds the BI view (vw_campaign_summary) from Gold
# MAGIC # 2) Adds view-level freshness columns (bi_view_created_ts/date)
# MAGIC # 3) Appends a row into an audit table so we can prove
# MAGIC #    when/who refreshed it, what was the source, and how fresh it is.
# MAGIC # ============================================================
# MAGIC
# MAGIC from pyspark.sql import functions as F
# MAGIC from datetime import datetime, timezone
# MAGIC
# MAGIC import json
# MAGIC
# MAGIC # --- Load my pipeline config so names stay in one place ---
# MAGIC config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
# MAGIC CATALOG    = config["catalog"]
# MAGIC GOLD_TABLE = config["gold_table"]                           # e.g. databricks_gcp_mars_powerbi.analytics.fact_campaign_performance
# MAGIC BI_VIEW    = config["bi_view"]                              # e.g. databricks_gcp_mars_powerbi.analytics.vw_campaign_summary
# MAGIC
# MAGIC spark.sql(f"USE CATALOG {CATALOG}")
# MAGIC spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")
# MAGIC
# MAGIC # I’ll keep one run id/timestamp across the job if the controller set it.
# MAGIC RUN_TS = None
# MAGIC RUN_ID = None
# MAGIC try:
# MAGIC     RUN_TS = spark.conf.get("dsp.run_ts")
# MAGIC     RUN_ID = spark.conf.get("dsp.run_id")
# MAGIC except Exception:
# MAGIC     # Fallbacks if not set by the controller
# MAGIC     RUN_TS = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
# MAGIC     RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
# MAGIC     spark.conf.set("dsp.run_ts", RUN_TS)
# MAGIC     spark.conf.set("dsp.run_id", RUN_ID)
# MAGIC
# MAGIC # ------------------------------------------------------------
# MAGIC # 1) (Re)create the BI view with explicit freshness columns
# MAGIC # ------------------------------------------------------------
# MAGIC # ------------------------------------------------------------
# MAGIC spark.sql(f"""
# MAGIC CREATE OR REPLACE VIEW {BI_VIEW} AS
# MAGIC SELECT
# MAGIC   month,
# MAGIC   format,
# MAGIC   device_type,
# MAGIC   bid_type,
# MAGIC   network_id,
# MAGIC   spend,
# MAGIC   impressions,
# MAGIC   clicks,
# MAGIC   measurable_imps,
# MAGIC   viewable_imps,
# MAGIC   engagements,
# MAGIC   video_start,
# MAGIC   video_complete,
# MAGIC   audio_start,
# MAGIC   audio_complete,
# MAGIC   cpm,
# MAGIC   cpe,
# MAGIC   ctr,
# MAGIC   viewability,
# MAGIC   engagement_rate,
# MAGIC   vcr,
# MAGIC   acr,
# MAGIC   gold_ingest_ts,
# MAGIC   gold_run_ts,
# MAGIC   current_timestamp() AS bi_view_created_ts,  -- when this view was (re)built
# MAGIC   current_date()      AS bi_view_created_date  -- friendly date for the dashboard
# MAGIC FROM {GOLD_TABLE}
# MAGIC """)
# MAGIC
# MAGIC # (Optional) Add a readable COMMENT on the view for catalog lineage
# MAGIC spark.sql(f"COMMENT ON VIEW {BI_VIEW} IS 'Business-facing summary for Power BI. Auto-refreshed from Gold with freshness fields.'")
# MAGIC
# MAGIC # ------------------------------------------------------------
# MAGIC # 2) Create an audit table (once), then append a row for this refresh
# MAGIC # ------------------------------------------------------------
# MAGIC AUDIT_TABLE = f"{CATALOG}.analytics.bi_metadata_audit"
# MAGIC
# MAGIC spark.sql(f"""
# MAGIC CREATE TABLE IF NOT EXISTS {AUDIT_TABLE} (
# MAGIC   bi_view_name      STRING,
# MAGIC   created_ts        TIMESTAMP,   -- exact timestamp when the view was rebuilt
# MAGIC   created_date      DATE,        -- human-readable date
# MAGIC   created_by        STRING,      -- who executed the refresh
# MAGIC   source_table      STRING,      -- Gold table used to build the view
# MAGIC   source_catalog    STRING,      -- current_catalog() at refresh time
# MAGIC   source_schema     STRING,      -- current_schema() at refresh time
# MAGIC   run_ts            STRING,      -- pipeline run timestamp (shared across job)
# MAGIC   run_id            STRING,      -- pipeline run id (shared across job)
# MAGIC   gold_last_run_ts  TIMESTAMP,   -- max(gold_run_ts) in the source table
# MAGIC   gold_last_ingest  TIMESTAMP,   -- max(gold_ingest_ts) in the source table
# MAGIC   gold_row_count    BIGINT,      -- number of rows in source at refresh time
# MAGIC   note              STRING       -- freeform comments if I need them
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Audit log of BI view refresh events for governance and SLA tracking.'
# MAGIC """)
# MAGIC
# MAGIC # Grab some quick source stats for the audit row (kept lightweight)
# MAGIC df_gold = spark.read.table(GOLD_TABLE)
# MAGIC gold_max = df_gold.agg(
# MAGIC     F.max("gold_run_ts").alias("max_run_ts"),
# MAGIC     F.max("gold_ingest_ts").alias("max_ingest_ts")
# MAGIC ).collect()[0]
# MAGIC gold_last_run_ts = gold_max["max_run_ts"]
# MAGIC gold_last_ingest = gold_max["max_ingest_ts"]
# MAGIC gold_row_count   = df_gold.count()
# MAGIC # ------------------------------------------------------------
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Inspect KPIs that triggered the alert
# MAGIC suspect_kpis = ["cpm", "cpe", "ctr", "viewability", "engagement_rate", "vcr", "acr"]
# MAGIC
# MAGIC for kpi in suspect_kpis:
# MAGIC     if kpi in dfg.columns:
# MAGIC         df_invalid = (
# MAGIC             dfg.filter(
# MAGIC                 (F.isnan(F.col(kpi))) |
# MAGIC                 (F.col(kpi).isNull()) |
# MAGIC                 (F.col(kpi) < 0) |
# MAGIC                 (F.col(kpi) > 1)   # applies only to ratio-type metrics
# MAGIC             )
# MAGIC         )
# MAGIC         count = df_invalid.count()
# MAGIC         if count > 0:
# MAGIC             print(f"⚠️ {kpi}: {count} invalid values")
# MAGIC             display(df_invalid.limit(10))
# MAGIC