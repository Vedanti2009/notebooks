# Databricks notebook source
# ============================================================
# DSP tables — quick health check across all layers
# Author: Vedanti Awaghade
# What it does (for each table):
#   • verifies existence
#   • counts rows
#   • shows latest run timestamp
#   • checks duplicate record_id (if present)
#   • checks nulls on key columns
#   • prints schema + sample rows
#   • builds a consolidated summary dataframe
# ============================================================

from pyspark.sql import functions as F
from pyspark.sql.utils import AnalysisException
from datetime import datetime
import json

# ---------- Load config ----------
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))

CATALOG       = config["catalog"]
BRONZE_TABLE  = config["bronze_table"]     # databricks_gcp_mars_powerbi.raw.dsp_bronze
SILVER_TABLE  = config["silver_table"]     # databricks_gcp_mars_powerbi.clean.dsp_silver
GOLD_TABLE    = config["gold_table"]       # databricks_gcp_mars_powerbi.analytics.fact_campaign_performance
DQ_TABLE      = f"{CATALOG}.analytics.fact_data_quality_issues"

spark.sql(f"USE CATALOG {CATALOG}")

# ---------- Expected columns per layer (for quick sanity) ----------
expected = {
    "bronze": ["record_id","month","format","device_type","bid_type","network_id",
               "spend","impressions","clicks","measurable_imps","viewable_imps",
               "engagements","video_start","video_complete","audio_start","audio_complete",
               "bronze_ingest_ts","bronze_source_file","load_timestamp","load_date"],
    "silver": ["record_id","month","format","device_type","bid_type","network_id",
               "spend","impressions","clicks","measurable_imps","viewable_imps",
               "engagements","video_start","video_complete","audio_start","audio_complete",
               "silver_ingest_ts","silver_run_ts"],
    "gold":   ["month","format","device_type","bid_type","network_id",
               "spend","impressions","clicks","measurable_imps","viewable_imps",
               "engagements","video_start","video_complete","audio_start","audio_complete",
               "cpm","cpe","ctr","viewability","engagement_rate","vcr","acr",
               "gold_ingest_ts","gold_run_ts"],
    "dq":     ["record_id","run_ts","_ingest_ts","data_quality_flag",
               "reason","rule_id","severity","failed_fields",
               "month","format","device_type","bid_type","network_id",
               "spend","impressions","clicks","measurable_imps","viewable_imps",
               "engagements","video_start","video_complete","audio_start","audio_complete","source_file"]
}

# ---------- Tables and their “latest run” column ----------
latest_cols = {
    "bronze": ("load_timestamp", BRONZE_TABLE),
    "silver": ("silver_run_ts",  SILVER_TABLE),
    "gold":   ("gold_run_ts",    GOLD_TABLE),
    "dq":     ("run_ts",         DQ_TABLE),
}

# ---------- Helper ----------
def _exists(fullname:str) -> bool:
    try:
        return spark.catalog.tableExists(fullname)
    except:
        return False

def check_table(layer: str, fullname: str) -> dict:
    """Return a dict with table health + print a concise view for eyeballing."""
    out = {
        "layer": layer,
        "table": fullname,
        "exists": False,
        "row_count": 0,
        "missing_columns": [],
        "latest_run_ts": None,
        "dup_record_id": None,
        "null_hotspots": {},    # null counts for key columns
        "note": ""
    }

    print(f"\n================= {layer.upper()} =================")
    print(f"Table: {fullname}")

    if not _exists(fullname):
        print("❌ Table does not exist.")
        out["note"] = "missing table"
        return out

    out["exists"] = True
    df = spark.table(fullname)

    # Row count
    rc = df.count()
    out["row_count"] = rc
    print(f"• Rows: {rc:,}")

    # Latest run ts
    latest_col = latest_cols.get(layer, (None, None))[0]
    if latest_col and latest_col in df.columns:
        try:
            latest_ts = df.agg(F.max(F.col(latest_col))).first()[0]
            out["latest_run_ts"] = latest_ts
            print(f"• Latest run ts ({latest_col}): {latest_ts}")
        except Exception as e:
            print(f"• Latest run ts error: {e}")
    else:
        print("• Latest run ts: N/A (column not found)")

    # Missing columns (against expected)
    expected_cols = expected.get(layer, [])
    missing = [c for c in expected_cols if c not in df.columns]
    out["missing_columns"] = missing
    if missing:
        print("• ⚠️ Missing columns:", ", ".join(missing))
    else:
        print("• ✅ Expected columns present (or not enforced for this layer)")

    # Duplicates on record_id (if present)
    if "record_id" in df.columns:
        dup = df.groupBy("record_id").count().filter("count > 1").count()
        out["dup_record_id"] = dup
        print(f"• Duplicate record_id: {dup:,}")
    else:
        print("• record_id not found (skip duplicate check).")

    # Null hotspots (key business cols)
    key_cols = ["month","format","device_type","bid_type","network_id","impressions","clicks","spend"]
    present_keys = [c for c in key_cols if c in df.columns]
    if rc > 0 and present_keys:
        exprs = [F.sum(F.when(F.col(c).isNull(), 1).otherwise(0)).alias(c) for c in present_keys]
        row = df.agg(*exprs).first().asDict()
        out["null_hotspots"] = {k:int(v) for k,v in row.items()}
        print("• Null counts (key columns):", {k:int(v) for k,v in row.items()})
    else:
        print("• Null counts skipped (no rows or no key columns).")

    # Print schema & sample
    print("• Schema:")
    df.printSchema()
    print("• Sample 5 rows:")
    display(df.limit(5))

    return out

# ---------- Run checks ----------
summary = []
summary.append(check_table("bronze", BRONZE_TABLE))
summary.append(check_table("silver", SILVER_TABLE))
summary.append(check_table("gold",   GOLD_TABLE))
summary.append(check_table("dq",     DQ_TABLE))

# ---------- Consolidated summary dataframe for audit ----------
summary_rows = []
for s in summary:
    summary_rows.append((
        s["layer"],
        s["table"],
        s["exists"],
        s["row_count"],
        s["latest_run_ts"],
        ", ".join(s["missing_columns"]) if s["missing_columns"] else "",
        s["dup_record_id"],
        json.dumps(s["null_hotspots"]) if s["null_hotspots"] else "{}",
        s["note"]
    ))

schema = "layer string, table string, exists boolean, row_count long, latest_run_ts string, missing_columns string, dup_record_id long, null_hotspots string, note string"
summary_df = spark.createDataFrame(summary_rows, schema=schema)
print("\n================= PIPELINE HEALTH SUMMARY =================")
display(summary_df.orderBy("layer"))
