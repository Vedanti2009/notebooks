# Databricks notebook source
# ============================================================
# 00_Reset_Cleanup_PreRun
# Author: Vedanti Awaghade
#
# Purpose:
#   Clears all tables and checkpoint folders before a fresh run
#   of the DSP ETL pipeline (Bronze → Silver → Gold).
# ============================================================

from datetime import datetime
import json

# ---------------------------
# Load pipeline config
# ---------------------------
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG        = config["catalog"]
BRONZE_TABLE   = config["bronze_table"]
SILVER_TABLE   = config["silver_table"]
GOLD_TABLE     = config["gold_table"]
DQ_TABLE       = f"{CATALOG}.analytics.fact_data_quality_issues"

BRONZE_CKPT    = config.get("bronze_checkpoint", "dbfs:/chkpt/dsp/bronze")
SCHEMA_LOC     = "dbfs:/chkpt/dsp/schema"
SNAPSHOT_PATH  = config.get("snapshot_path", None)

spark.sql(f"USE CATALOG {CATALOG}")

# ---------------------------
# Helper utilities
# ---------------------------
def safe_drop(table_name):
    try:
        spark.sql(f"DROP TABLE IF EXISTS {table_name}")
        print(f"🗑️ Dropped table → {table_name}")
    except Exception as e:
        print(f"⚠️ Could not drop {table_name} → {e}")

def safe_delete(path):
    try:
        dbutils.fs.rm(path, True)
        print(f"🧹 Deleted path → {path}")
    except Exception as e:
        print(f"⚠️ Could not delete {path} → {e}")

# ---------------------------
# 1️⃣ Drop tables (clean slate)
# ---------------------------
safe_drop(BRONZE_TABLE)
safe_drop(SILVER_TABLE)
safe_drop(GOLD_TABLE)
safe_drop(DQ_TABLE)

# ---------------------------
# 2️⃣ Remove checkpoints / schema folders
# ---------------------------
safe_delete(BRONZE_CKPT)
safe_delete(SCHEMA_LOC)

# ---------------------------
# 3️⃣ Optional: clean backup snapshot folder
# ---------------------------
if SNAPSHOT_PATH:
    safe_delete(SNAPSHOT_PATH)

# ---------------------------
# 4️⃣ Run timestamp (for logs)
# ---------------------------
RUN_TS = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"\n✅ Cleanup complete at {RUN_TS}")
