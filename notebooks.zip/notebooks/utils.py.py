# Databricks notebook source
# utils.py — simple, audit-friendly helpers reused across notebooks.

from databricks.sdk.runtime import *  # ensures dbutils works in Python cells
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from typing import Dict, Optional, Iterable
import json, os, re

# --- Path handling -----------------------------------------------------------

def _is_dbfs(path: str) -> bool:
    return path.startswith("dbfs:/")

def _normalize_workspace_path(path: str) -> str:
    # Support Workspace files via file: prefix if you ever pass "/Workspace/.."
    if path.startswith("/Workspace/"):
        return f"file:{path}"
    return path

# --- Config ------------------------------------------------------------------

def load_config(path: str) -> Dict:
    """
    Load JSON config from:
      - dbfs:/... (via dbutils)
      - /Workspace/... (via file:)
      - file:/... or local filesystem
    """
    if _is_dbfs(path):
        txt = dbutils.fs.head(path, 10_000_000)
        cfg = json.loads(txt)
        print(f"[config] loaded (dbfs): {path}")
        return cfg

    path = _normalize_workspace_path(path)
    if path.startswith("file:"):
        txt = dbutils.fs.head(path, 10_000_000)
        cfg = json.loads(txt)
        print(f"[config] loaded (file): {path}")
        return cfg

    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        print(f"[config] loaded (local): {path}")
        return cfg

    raise FileNotFoundError(f"Config not found: {path}")

# --- Filesystem --------------------------------------------------------------

def ensure_dir(path: str) -> None:
    """Create a directory on DBFS or local FS if it doesn't exist."""
    if _is_dbfs(path):
        dbutils.fs.mkdirs(path)
    else:
        os.makedirs(path, exist_ok=True)

# --- DataFrame hygiene -------------------------------------------------------

def clean_headers(df: DataFrame) -> DataFrame:
    """Normalize column names (lowercase, non-alnum -> _, collapse repeats)."""
    new_cols = []
    for c in df.columns:
        nc = c.strip().lower()
        nc = re.sub(r"[^\w]+", "_", nc)      # non-alnum -> _
        nc = re.sub(r"_+", "_", nc).strip("_")
        if not nc:
            nc = "col"
        new_cols.append(nc)
    if new_cols != df.columns:
        print("[headers] rename map:", dict(zip(df.columns, new_cols)))
    return df.toDF(*new_cols)

def to_double(df: DataFrame, cols: Iterable[str]) -> DataFrame:
    """
    Safely cast selected columns to double:
    - strip commas/spaces
    - treat '' as null before cast
    """
    out = df
    for c in cols:
        if c in out.columns:
            out = out.withColumn(
                c,
                F.when(F.trim(F.col(c).cast("string")) == "", F.lit(None))
                 .otherwise(F.regexp_replace(F.col(c).cast("string"), r"[,\s]", ""))
                 .cast("double")
            )
    return out

def add_lineage(df: DataFrame, source: str, tag: Optional[str] = None) -> DataFrame:
    """
    Add standard audit columns if they don't already exist:
      - ingested_at (timestamp)
      - ingested_by (user)
      - source (literal string)
      - tag (optional literal)
    """
    out = df
    if "ingested_at" not in out.columns:
        out = out.withColumn("ingested_at", F.current_timestamp())
    if "ingested_by" not in out.columns:
        out = out.withColumn("ingested_by", F.expr("current_user()"))
    if "source" not in out.columns:
        out = out.withColumn("source", F.lit(source))
    if tag and "tag" not in out.columns:
        out = out.withColumn("tag", F.lit(tag))
    return out
