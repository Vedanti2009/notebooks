# Databricks notebook source
# ============================================================
# DATA QUALITY TABLE CREATION SCRIPT (with record_id)
# Author: Vedanti Awaghade
#
# Purpose:
#   Store rows that fail validation rules during Silver processing.
#   Each record now includes a deterministic `record_id` for lineage.
# ============================================================

from pyspark.sql import SparkSession
import json

# Load config
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG = config["catalog"]
DQ_TABLE = f"{CATALOG}.analytics.fact_data_quality_issues"

spark = SparkSession.builder.getOrCreate()
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")

# Create DQ Table (raw-only, with record_id)
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DQ_TABLE} (
  -- lineage
  run_ts            STRING,
  reason            STRING,
  rule_id           STRING,
  severity          STRING,
  failed_fields     ARRAY<STRING>,
  _ingest_ts        TIMESTAMP,
  bronze_ingest_ts  TIMESTAMP,
  source_file       STRING,
  record_id         STRING,             -- deterministic ID from Bronze

  -- identifiers
  month             DATE,
  network_id        STRING,
  format            STRING,
  device_type       STRING,
  bid_type          STRING,

  -- raw metrics
  impressions       DOUBLE,
  clicks            DOUBLE,
  measurable_imps   DOUBLE,
  viewable_imps     DOUBLE,
  spend             DOUBLE,
  engagements       DOUBLE,
  video_start       DOUBLE,
  video_complete    DOUBLE,
  audio_start       DOUBLE,
  audio_complete    DOUBLE,

  data_quality_flag STRING              -- 'Failed'
)
USING DELTA
COMMENT 'Records failing validation rules from Silver transform (raw-only + record_id).'
""")

print(f"✅ DQ table ready → {DQ_TABLE}")
