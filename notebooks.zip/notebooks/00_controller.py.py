# Databricks notebook source
# ============================================================
# 00_controller — run setup: backup, clear checkpoints, helpers
# Author: Vedanti Awaghade
# ============================================================
import json, re
from datetime import datetime, timezone

# I keep all names in one config so I don't scatter constants
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))

CATALOG       = config["catalog"]
BRONZE_TABLE  = config["bronze_table"]
SILVER_TABLE  = config["silver_table"]
GOLD_TABLE    = config["gold_table"]
SNAPSHOT_ROOT = config["snapshot_path"]                  # e.g., gs://mars-casestudy/backups/fact_campaign_performance/
BRONZE_CKPT   = config.get("bronze_checkpoint","dbfs:/chkpt/dsp/bronze")
SILVER_CKPT   = "dbfs:/chkpt/dsp/silver_stream"

# One run id/timestamp for the entire pipeline (UTC + consistent everywhere)
RUN_TS_STR = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
RUN_ID     = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
spark.conf.set("dsp.run_ts", RUN_TS_STR)
spark.conf.set("dsp.run_id", RUN_ID)

# Make sure I'm on the right UC catalog (some clusters default elsewhere)
cur = spark.sql("SELECT current_catalog()").collect()[0][0]
if cur != CATALOG:
    spark.sql(f"USE CATALOG {CATALOG}")

def _safe_name(full_table:str)->str:
    # Convert catalog.schema.table -> catalog_schema_table for folder names
    return re.sub(r"[.]", "_", full_table)

def _table_exists(full_name: str) -> bool:
    try:
        return spark.catalog.tableExists(full_name)
    except Exception:
        return False

def backup_table(table_name:str, layer:str, enabled:bool=True):
    """
    I snapshot the current table into GCS so I can restore or compare runs later.
    If the table doesn't exist or is empty, I skip to save time/cost.
    """
    if not enabled:
        print(f"[backup] disabled for {table_name}")
        return
    try:
        if not _table_exists(table_name):
            print(f"[backup] {table_name}: not found, skip")
            return
        df = spark.table(table_name)
        if df.rdd.isEmpty():
            print(f"[backup] {table_name}: empty, skip")
            return
        dest = f"{SNAPSHOT_ROOT.rstrip('/')}/{layer}/table={_safe_name(table_name)}/run_ts={RUN_ID}/"
        print(f"[backup] {table_name} -> {dest}")
        df.write.format("delta").mode("overwrite").save(dest)
    except Exception as e:
        print(f"[backup] {table_name}: {e}")

def clear_checkpoints():
    """
    I reset streaming checkpoints so Auto Loader (and any stream) reprocesses
    from scratch for this run. Helpful when I want a clean rerun/demo.
    """
    for p in [BRONZE_CKPT, SILVER_CKPT]:
        try:
            dbutils.fs.rm(p, recurse=True)
            print(f"[ckpt] cleared {p}")
        except Exception as e:
            print(f"[ckpt] could not clear {p}: {e}")

def purge_to_current_run(table_name:str, ts_col:str, run_ts:str):
    """
    For tables that keep history by run_ts, this keeps only the current run’s rows.
    Useful when I want the tables to show only "latest snapshot" to BI.
    """
    try:
        if not _table_exists(table_name):
            print(f"[purge] {table_name}: not found, skip")
            return
        cols = [r.col_name.lower() for r in spark.sql(f"DESCRIBE {table_name}").select("col_name").collect()]
        if ts_col.lower() not in cols:
            spark.sql(f"ALTER TABLE {table_name} ADD COLUMNS ({ts_col} STRING)")
            print(f"[purge] added {ts_col} on {table_name}")
        spark.sql(f"DELETE FROM {table_name} WHERE {ts_col} IS NULL OR {ts_col} <> '{run_ts}'")
        left = spark.table(table_name).count()
        print(f"[purge] {table_name}: kept {left:,} rows for {ts_col}='{run_ts}'")
    except Exception as e:
        print(f"[purge] {table_name}: {e}")

# ---------- run this at the start of a fresh pipeline ----------
print(f"Run initialized. RUN_TS={RUN_TS_STR}  RUN_ID={RUN_ID}")

# 1) Backup current tables (toggle off if you just want delete-only mode)
BACKUP = True
backup_table(BRONZE_TABLE, "bronze", BACKUP)
backup_table(SILVER_TABLE, "silver", BACKUP)
backup_table(GOLD_TABLE,   "gold",   BACKUP)

# 2) Clear checkpoints so the next notebooks reprocess cleanly
clear_checkpoints()

# (Optional) If I want my Silver/Gold to only retain current run, I’ll call:
# purge_to_current_run(SILVER_TABLE, "silver_run_ts", RUN_TS_STR)
# purge_to_current_run(GOLD_TABLE,   "gold_run_ts",   RUN_TS_STR)
