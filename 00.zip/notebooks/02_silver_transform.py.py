# Databricks notebook source
# ============================================================
# SILVER HYBRID TRANSFORMATION + DQ LOGGING
# Author: Vedanti Awaghade
#
# Purpose:
#   Unified Silver pipeline that:
#   - Cleans and standardizes data from Bronze
#   - Applies validation rules before KPI computation
#   - Logs all invalid records to a structured DQ table
#   - Outputs a validated Silver table for analytics
# ============================================================

from pyspark.sql import functions as F
from datetime import datetime
import json

# ---------------------------
# Load Config & Setup
# ---------------------------
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG      = config["catalog"]
BRONZE_TABLE = config["bronze_table"]
SILVER_TABLE = config["silver_table"]
DQ_TABLE     = f"{CATALOG}.analytics.fact_data_quality_issues"

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")

# Unified timestamp for entire run
RUN_TS = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"Starting Silver Hybrid Run → {RUN_TS}")

# ============================================================
# 1️⃣ READ BRONZE & TYPE NORMALIZATION
# ============================================================
df = spark.read.table(BRONZE_TABLE)

# Clean numeric columns
num_cols = [
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete"
]
for c in num_cols:
    if c in df.columns:
        df = df.withColumn(c, F.regexp_replace(F.col(c).cast("string"), r"[, ]", "").cast("double"))

# Clean text columns
for c in ["format","device_type","bid_type","network_id"]:
    if c in df.columns:
        df = df.withColumn(c, F.lower(F.trim(F.col(c).cast("string"))))

# Normalize month column
if "month" in df.columns:
    df = df.withColumn(
        "month",
        F.coalesce(
            F.to_date(F.concat(F.lit("01-"), F.col("month")), "dd-MMM-yyyy"),
            F.to_date("month","yyyy-MM-dd"),
            F.to_date("month","yyyy/MM"),
            F.to_date("month")
        )
    )

# ============================================================
# 2️⃣ VALIDATION RULES
# ============================================================
valid_cond = (
    (F.col("impressions").isNotNull()) & (F.col("impressions") > 0) &
    (F.col("spend").isNotNull()) & (F.col("spend") >= 0) &
    (F.col("clicks") <= F.col("impressions")) &
    (F.col("viewable_imps") <= F.col("measurable_imps"))
)

df_valid   = df.filter(valid_cond)
df_invalid = df.filter(~valid_cond)

print(f"Bronze Rows: {df.count()} | ✅ Valid: {df_valid.count()} | ❌ Invalid: {df_invalid.count()}")

# ============================================================
# 3️⃣ CREATE/APPEND DATA QUALITY TABLE (structured schema)
# ============================================================
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DQ_TABLE} (
  run_ts STRING,
  rule_id STRING,
  reason STRING,
  severity STRING,
  failed_fields ARRAY<STRING>,
  record_id STRING,
  month DATE,
  network_id STRING,
  format STRING,
  device_type STRING,
  bid_type STRING,
  impressions DOUBLE,
  clicks DOUBLE,
  measurable_imps DOUBLE,
  viewable_imps DOUBLE,
  spend DOUBLE,
  _ingest_ts TIMESTAMP,
  data_quality_flag STRING
) USING DELTA
COMMENT 'Centralized DQ log for invalid Silver rows.'
""")

if df_invalid.count() > 0:
    dq_df = (
        df_invalid
        .withColumn("run_ts", F.lit(RUN_TS))
        .withColumn(
            "reason",
            F.when(F.col("clicks") > F.col("impressions"), "clicks_gt_impressions")
             .when(F.col("viewable_imps") > F.col("measurable_imps"), "viewable_gt_measurable")
             .when(F.col("spend") < 0, "negative_spend")
             .when(F.col("impressions") <= 0, "zero_or_null_impressions")
             .otherwise("unknown_reason")
        )
        .withColumn(
            "rule_id",
            F.when(F.col("reason")=="clicks_gt_impressions","DQ01")
             .when(F.col("reason")=="viewable_gt_measurable","DQ02")
             .when(F.col("reason")=="negative_spend","DQ03")
             .when(F.col("reason")=="zero_or_null_impressions","DQ04")
             .otherwise("DQ00")
        )
        .withColumn(
            "severity",
            F.when(F.col("reason").isin("clicks_gt_impressions","viewable_gt_measurable"),"high")
             .when(F.col("reason")=="negative_spend","medium")
             .otherwise("low")
        )
        .withColumn(
            "failed_fields",
            F.when(F.col("reason")=="clicks_gt_impressions", F.array(F.lit("clicks"),F.lit("impressions")))
             .when(F.col("reason")=="viewable_gt_measurable", F.array(F.lit("viewable_imps"),F.lit("measurable_imps")))
             .when(F.col("reason")=="negative_spend", F.array(F.lit("spend")))
             .when(F.col("reason")=="zero_or_null_impressions", F.array(F.lit("impressions")))
             .otherwise(F.array())
        )
        .withColumn("_ingest_ts", F.current_timestamp())
        .withColumn("data_quality_flag", F.lit("Failed"))
        .select("run_ts","rule_id","reason","severity","failed_fields",
                "record_id","month","network_id","format","device_type","bid_type",
                "impressions","clicks","measurable_imps","viewable_imps","spend",
                "_ingest_ts","data_quality_flag")
    )
    dq_df.write.mode("append").saveAsTable(DQ_TABLE)
    print(f"✅ DQ rows logged → {DQ_TABLE}")
else:
    print("✅ No data quality issues found.")

# ============================================================
# 4️⃣ WRITE SILVER OUTPUT
# ============================================================
silver_cols = [
    "record_id","month","format","device_type","bid_type","network_id",
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete"
]
df_silver = (
    df_valid.select([c for c in silver_cols if c in df_valid.columns])
            .withColumn("silver_ingest_ts", F.current_timestamp())
            .withColumn("silver_run_ts", F.lit(RUN_TS))
)

spark.sql(f"DROP TABLE IF EXISTS {SILVER_TABLE}")
df_silver.write.mode("overwrite").saveAsTable(SILVER_TABLE)
print(f"✅ Silver refreshed → {SILVER_TABLE}")
display(df_silver.limit(10))


# COMMAND ----------

# ============================================================
# SILVER VALIDATION — quick, audit-friendly checks
# Author: Vedanti Awaghade
# ============================================================

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta
import json

# ---------------------------
# Load pipeline config
# ---------------------------
config       = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG      = config["catalog"]
BRONZE_TABLE = config["bronze_table"]                                   # e.g., databricks_gcp_mars_powerbi.raw.dsp_bronze
SILVER_TABLE = config["silver_table"]                                   # e.g., databricks_gcp_mars_powerbi.clean.dsp_silver
DQ_TABLE     = f"{CATALOG}.analytics.fact_data_quality_issues"

spark.sql(f"USE CATALOG {CATALOG}")

# ---------------------------
# Helper: safe table existence
# ---------------------------
def table_exists(full_name: str) -> bool:
    try:
        return spark.catalog.tableExists(full_name)
    except Exception:
        return False

# ---------------------------
# 0) Existence checks
# ---------------------------
problems = []

if not table_exists(BRONZE_TABLE):
    problems.append(f"Missing Bronze table: {BRONZE_TABLE}")
if not table_exists(SILVER_TABLE):
    problems.append(f"Missing Silver table: {SILVER_TABLE}")
if not table_exists(DQ_TABLE):
    problems.append(f"Missing DQ table: {DQ_TABLE}")

if problems:
    print("❌ Validation halted — required table(s) missing:")
    for p in problems:
        print("  •", p)
else:
    # ---------------------------
    # 1) Basic counts & freshness
    # ---------------------------
    df_bronze = spark.read.table(BRONZE_TABLE)
    df_silver = spark.read.table(SILVER_TABLE)
    df_dq     = spark.read.table(DQ_TABLE)

    bronze_cnt = df_bronze.count()
    silver_cnt = df_silver.count()
    dq_cnt     = df_dq.count()

    # Silver freshness: ensure last load is recent (<= 6 hours by default)
    max_ingest = df_silver.agg(F.max("silver_ingest_ts").alias("ts")).collect()[0]["ts"]
    freshness_min = None
    if max_ingest:
        freshness_min = (datetime.utcnow() - max_ingest.replace(tzinfo=None)).total_seconds()/60

    print(f"Bronze rows : {bronze_cnt:,}")
    print(f"Silver rows : {silver_cnt:,}")
    print(f"DQ rows     : {dq_cnt:,}")
    print(f"Silver max(silver_ingest_ts): {max_ingest} (freshness ≈ {round(freshness_min,1) if freshness_min is not None else 'NA'} min)")

    # ---------------------------
    # 2) Required columns present?
    # ---------------------------
    required_cols = {
        "record_id","month","format","device_type","bid_type","network_id",
        "spend","impressions","clicks","measurable_imps","viewable_imps",
        "engagements","video_start","video_complete","audio_start","audio_complete",
        "silver_ingest_ts","silver_run_ts"
    }
    missing = sorted(list(required_cols - set(df_silver.columns)))
    if missing:
        problems.append(f"Silver missing columns: {missing}")

    # ---------------------------
    # 3) Uniqueness & null health
    # ---------------------------
    dup_record_id = df_silver.groupBy("record_id").count().filter("count > 1").count() if "record_id" in df_silver.columns else None

    # Null ratio for critical fields
    critical = ["record_id","month","format","device_type","bid_type","network_id",
                "impressions","clicks","spend"]
    null_stats = []
    total = float(silver_cnt) if silver_cnt else 1.0
    for c in critical:
        if c in df_silver.columns:
            n = df_silver.filter(F.col(c).isNull()).count()
            null_stats.append((c, n, round(100.0*n/total, 3)))

    # ---------------------------
    # 4) Re-run the business rules on Silver (should be 0)
    # ---------------------------
    rule_clicks_gt_imprs = df_silver.filter(F.col("clicks") > F.col("impressions")).count()
    rule_view_gt_meas    = df_silver.filter(F.col("viewable_imps") > F.col("measurable_imps")).count()
    rule_neg_spend       = df_silver.filter(F.col("spend") < 0).count()
    rule_zero_imprs      = df_silver.filter(F.col("impressions") <= 0).count()

    # ---------------------------
    # 5) Month sanity + numeric sign checks
    # ---------------------------
    month_nulls = df_silver.filter(F.col("month").isNull()).count()
    month_minmax = df_silver.agg(F.min("month").alias("min_m"), F.max("month").alias("max_m")).collect()[0]
    numeric_neg = {}
    for ncol in ["spend","impressions","clicks","measurable_imps","viewable_imps",
                 "engagements","video_start","video_complete","audio_start","audio_complete"]:
        if ncol in df_silver.columns:
            cnt_neg = df_silver.filter(F.col(ncol) < 0).count()
            if cnt_neg > 0:
                numeric_neg[ncol] = cnt_neg

    # ---------------------------
    # 6) Reconciliation: Bronze = Silver + DQ  (row-level)
    # ---------------------------
    # This is approximate because DQ is append-only history. For a strict “run”, filter DQ by run_ts.
    recon_diff = bronze_cnt - (silver_cnt + dq_cnt)

    # ---------------------------
    # 7) Print summary
    # ---------------------------
    print("\n=== VALIDATION SUMMARY ===============================")
    print(f"• Missing columns         : {missing if missing else 'None'}")
    print(f"• Duplicate record_id     : {dup_record_id if dup_record_id is not None else 'N/A'}")
    print(f"• Month nulls             : {month_nulls:,}")
    print(f"• Month min/max           : {month_minmax['min_m']}  →  {month_minmax['max_m']}")
    print(f"• Rule violations in Silver (should be 0):")
    print(f"    - clicks > impressions : {rule_clicks_gt_imprs}")
    print(f"    - viewable > measurable: {rule_view_gt_meas}")
    print(f"    - negative spend       : {rule_neg_spend}")
    print(f"    - impressions <= 0     : {rule_zero_imprs}")
    if numeric_neg:
        print(f"• Negative values found   : {numeric_neg}")
    print(f"• Reconciliation (Bronze - Silver - DQ): {recon_diff}")

    print("\n• Null ratios (critical columns)")
    for c, n, pct in null_stats:
        print(f"   - {c:<15} : {n:>6} rows  ({pct:>6.3f}%)")

    # ---------------------------
    # 8) Hard “alerts” (optional)
    # ---------------------------
    alerts = []
    if dup_record_id and dup_record_id > 0:
        alerts.append("Duplicate record_id detected in Silver.")
    if month_nulls > 0:
        alerts.append("Null month values present in Silver.")
    if any([rule_clicks_gt_imprs, rule_view_gt_meas, rule_neg_spend, rule_zero_imprs]):
        alerts.append("At least one business rule still violates in Silver.")
    if freshness_min is not None and freshness_min > 360:  # > 6 hours
        alerts.append(f"Silver looks stale (last load {round(freshness_min,1)} minutes ago).")
    if recon_diff != 0:
        alerts.append("Reconciliation mismatch: Bronze != Silver + DQ (use run_ts filter on DQ if needed).")

    if alerts:
        print("\n⚠️  ALERTS:")
        for a in alerts:
            print("   •", a)
    else:
        print("\n✅ Silver validation passed the main checks.")


# COMMAND ----------

# MAGIC %sql
# MAGIC -- Set this once per run (controller usually sets it)
# MAGIC -- SET dsp.run_ts = '2025-10-29 14:23:00';
# MAGIC
# MAGIC DELETE FROM databricks_gcp_mars_powerbi.analytics.fact_data_quality_issues
# MAGIC WHERE run_ts = '${dsp.run_ts}' AND rule_id IN ('DQ05','DQ06','DQ07');
# MAGIC
# MAGIC INSERT INTO databricks_gcp_mars_powerbi.analytics.fact_data_quality_issues
# MAGIC SELECT
# MAGIC   '${dsp.run_ts}'                           AS run_ts,
# MAGIC   i.reason                                  AS reason,
# MAGIC   i.rule_id                                  AS rule_id,
# MAGIC   i.severity                                 AS severity,
# MAGIC   i.failed_fields                            AS failed_fields,
# MAGIC   current_timestamp()                        AS _ingest_ts,
# MAGIC   s.bronze_ingest_ts,
# MAGIC   s.source_file,
# MAGIC   s.record_id, s.month, s.network_id, s.format, s.device_type, s.bid_type,
# MAGIC   s.impressions, s.clicks, s.measurable_imps, s.viewable_imps, s.spend,
# MAGIC   s.engagements, s.video_start, s.video_complete, s.audio_start, s.audio_complete,
# MAGIC   'Failed'                                   AS data_quality_flag
# MAGIC FROM databricks_gcp_mars_powerbi.clean.dsp_silver s
# MAGIC LATERAL VIEW explode(array(
# MAGIC   CASE WHEN s.spend <= 0 THEN named_struct(
# MAGIC        'rule_id','DQ05','reason','invalid_spend_nonpositive','severity','medium','failed_fields',array('spend')) END,
# MAGIC   CASE WHEN s.impressions IS NULL THEN named_struct(
# MAGIC        'rule_id','DQ06','reason','impressions_null','severity','high','failed_fields',array('impressions')) END,
# MAGIC   CASE WHEN s.clicks IS NULL THEN named_struct(
# MAGIC        'rule_id','DQ07','reason','clicks_null','severity','medium','failed_fields',array('clicks')) END
# MAGIC )) i
# MAGIC WHERE i.rule_id IS NOT NULL;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT rule_id, reason, COUNT(*) AS rows
# MAGIC FROM databricks_gcp_mars_powerbi.analytics.fact_data_quality_issues
# MAGIC WHERE run_ts = '${dsp.run_ts}'
# MAGIC GROUP BY rule_id, reason
# MAGIC ORDER BY rows DESC;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT record_id, COUNT(*) AS issues
# MAGIC FROM databricks_gcp_mars_powerbi.analytics.fact_data_quality_issues
# MAGIC WHERE run_ts = '${dsp.run_ts}' AND rule_id IN ('DQ05','DQ06','DQ07')
# MAGIC GROUP BY record_id
# MAGIC ORDER BY issues DESC;
# MAGIC