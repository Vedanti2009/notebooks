# Databricks notebook source
 VIE

# COMMAND ----------

# ============================================================
# GOLD – KPI FACT + BI VIEW
# Author: Vedanti Awaghade
#
# What this does:
# 1) Reads Silver (row-level, valid-only with record_id).
# 2) Aggregates to a business grain (month, format, device_type, bid_type, network_id).
# 3) Calculates KPIs:
#       - CPM = spend / impressions * 1000
#       - CPE = spend / engagements
#       - CTR = clicks / impressions
#       - Viewability = viewable_imps / measurable_imps
#       - Engagement Rate = engagements / clicks
#       - VCR = video_complete / video_start
#       - ACR = audio_complete / audio_start
# 4) Writes a fresh Gold table (overwrite latest snapshot).
# 5) Creates/updates a BI view that is easy for Power BI to consume.
# 6) (Optional) Saves a partitioned snapshot to GCS for backup/audits.
# ============================================================

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime
import json

# ---------- Run stamp (consistent across notebooks if set) ----------
dbutils.widgets.text("run_ts", "")
try:
    RUN_TS = dbutils.widgets.get("run_ts") or spark.conf.get("dsp.run_ts")
except Exception:
    RUN_TS = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    spark.conf.set("dsp.run_ts", RUN_TS)

# ---------- Load config ----------
config       = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG      = config["catalog"]
SILVER_TABLE = config["silver_table"]
GOLD_TABLE   = config["gold_table"]
BI_VIEW      = config["bi_view"]
SNAPSHOT_GCS = config.get("snapshot_path")  # optional

spark.sql(f"USE CATALOG {CATALOG}")

print(f"Gold run         → {RUN_TS}")
print(f"Source (Silver)  → {SILVER_TABLE}")
print(f"Target (Gold)    → {GOLD_TABLE}")
print(f"BI view          → {BI_VIEW}")

# ============================================================
# 0) Read Silver
# ============================================================
dfs = spark.read.table(SILVER_TABLE)

# Guard: required numeric cols present
needed = {
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete"
}
missing = needed - set(dfs.columns)
if missing:
    raise ValueError(f"Silver is missing required columns: {sorted(list(missing))}")

# ============================================================
# 1) Aggregate to business grain
#    (month, format, device_type, bid_type, network_id)
# ============================================================
grain = ["month","format","device_type","bid_type","network_id"]

df_agg = (
    dfs.groupBy(grain)
       .agg(
           F.sum("spend").alias("spend"),
           F.sum("impressions").alias("impressions"),
           F.sum("clicks").alias("clicks"),
           F.sum("measurable_imps").alias("measurable_imps"),
           F.sum("viewable_imps").alias("viewable_imps"),
           F.sum("engagements").alias("engagements"),
           F.sum("video_start").alias("video_start"),
           F.sum("video_complete").alias("video_complete"),
           F.sum("audio_start").alias("audio_start"),
           F.sum("audio_complete").alias("audio_complete")
       )
)

# ============================================================
# 2) KPI calculations (null/zero safe)
#    Using safe divisions to avoid NaN/Inf.
# ============================================================
def safe_div(n, d):
    return F.when((d.isNull()) | (d == 0), F.lit(None).cast("double")).otherwise(n / d)

df_gold = (
    df_agg
      .withColumn("cpm",  safe_div(F.col("spend"), F.col("impressions")) * F.lit(1000.0))
      .withColumn("cpe",  safe_div(F.col("spend"), F.col("engagements")))
      .withColumn("ctr",  safe_div(F.col("clicks"), F.col("impressions")))
      .withColumn("viewability",     safe_div(F.col("viewable_imps"), F.col("measurable_imps")))
      .withColumn("engagement_rate", safe_div(F.col("engagements"), F.col("clicks")))
      .withColumn("vcr",  safe_div(F.col("video_complete"), F.col("video_start")))
      .withColumn("acr",  safe_div(F.col("audio_complete"), F.col("audio_start")))
      .withColumn("gold_ingest_ts", F.current_timestamp())
      .withColumn("gold_run_ts", F.lit(RUN_TS))
)

# Optional: round KPIs for reporting neatness (keep raw in separate table if you need full precision)
for k in ["cpm","cpe","ctr","viewability","engagement_rate","vcr","acr"]:
    df_gold = df_gold.withColumn(k, F.round(F.col(k), 6))

# Column order (nice for BI)
ordered = grain + [
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete",
    "cpm","cpe","ctr","viewability","engagement_rate","vcr","acr",
    "gold_ingest_ts","gold_run_ts"
]
df_gold = df_gold.select(*ordered)

# ============================================================
# 3) Write/replace Gold table (latest-only snapshot)
# ============================================================
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")
spark.sql(f"DROP TABLE IF EXISTS {GOLD_TABLE}")
df_gold.write.mode("overwrite").saveAsTable(GOLD_TABLE)

print(f"✅ Gold table refreshed: {GOLD_TABLE}")
display(df_gold.limit(10))

# ============================================================
# 4) Create / Replace BI View (thin layer for Power BI)
#    Keeps field names business-friendly and exposes KPIs.
# ============================================================
spark.sql(f"""
CREATE OR REPLACE VIEW {BI_VIEW} AS
SELECT
  month,
  format,
  record_id,
  device_type,
  bid_type,
  network_id,
  spend,
  impressions,
  clicks,
  measurable_imps,
  viewable_imps,
  engagements,
  video_start,
  video_complete,
  audio_start,
  audio_complete,
  cpm,
  cpe,
  ctr,
  viewability,
  engagement_rate,
  vcr,
  acr,
  gold_ingest_ts,
  gold_run_ts,
  current_timestamp() AS bi_view_created_ts,  -- 🔹 New: BI view creation timestamp
    current_date() AS bi_view_created_date  
FROM {GOLD_TABLE}
""")

print(f"✅ BI view created/updated: {BI_VIEW}")

# ============================================================
# 5) Optional: write a snapshot to GCS for audit/backup
#    This writes partitioned by month for easy retrieval.
# ============================================================
if SNAPSHOT_GCS:
    out = SNAPSHOT_GCS.rstrip("/")
    (df_gold
        .repartition("month")
        .write
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .format("delta")
        .partitionBy("month")
        .save(out))
    print(f"🧷 Snapshot written to: {out}")


# COMMAND ----------

# ============================================================
# BI VIEW + GOVERNANCE AUDIT
# Author: Vedanti Awaghade
#
# What this does:
# 1) Rebuilds the BI view (vw_campaign_summary) from Gold
# 2) Adds view-level freshness columns (bi_view_created_ts/date)
# 3) Appends a row into an audit table so we can prove
#    when/who refreshed it, what was the source, and how fresh it is.
# ============================================================

from pyspark.sql import functions as F
from datetime import datetime
import json

# --- Load my pipeline config so names stay in one place ---
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG    = config["catalog"]
GOLD_TABLE = config["gold_table"]                           # e.g. databricks_gcp_mars_powerbi.analytics.fact_campaign_performance
BI_VIEW    = config["bi_view"]                              # e.g. databricks_gcp_mars_powerbi.analytics.vw_campaign_summary

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.analytics")

# I’ll keep one run id/timestamp across the job if the controller set it.
RUN_TS = None
RUN_ID = None
try:
    RUN_TS = spark.conf.get("dsp.run_ts")
    RUN_ID = spark.conf.get("dsp.run_id")
except Exception:
    # Fallbacks if not set by the controller
    RUN_TS = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    RUN_ID = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    spark.conf.set("dsp.run_ts", RUN_TS)
    spark.conf.set("dsp.run_id", RUN_ID)

# ------------------------------------------------------------
# 1) (Re)create the BI view with explicit freshness columns
# ------------------------------------------------------------
spark.sql(f"""
CREATE OR REPLACE VIEW {BI_VIEW} AS
SELECT
  month,
  format,
  device_type,
  bid_type,
  network_id,
  spend,
  impressions,
  clicks,
  measurable_imps,
  viewable_imps,
  engagements,
  video_start,
  video_complete,
  audio_start,
  audio_complete,
  cpm,
  cpe,
  ctr,
  viewability,
  engagement_rate,
  vcr,
  acr,
  gold_ingest_ts,
  gold_run_ts,
  current_timestamp() AS bi_view_created_ts,  -- when this view was (re)built
  current_date()      AS bi_view_created_date  -- friendly date for the dashboard
FROM {GOLD_TABLE}
""")

# (Optional) Add a readable COMMENT on the view for catalog lineage
spark.sql(f"COMMENT ON VIEW {BI_VIEW} IS 'Business-facing summary for Power BI. Auto-refreshed from Gold with freshness fields.'")

# ------------------------------------------------------------
# 2) Create an audit table (once), then append a row for this refresh
# ------------------------------------------------------------
AUDIT_TABLE = f"{CATALOG}.analytics.bi_metadata_audit"

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {AUDIT_TABLE} (
  bi_view_name      STRING,
  created_ts        TIMESTAMP,   -- exact timestamp when the view was rebuilt
  created_date      DATE,        -- human-readable date
  created_by        STRING,      -- who executed the refresh
  source_table      STRING,      -- Gold table used to build the view
  source_catalog    STRING,      -- current_catalog() at refresh time
  source_schema     STRING,      -- current_schema() at refresh time
  run_ts            STRING,      -- pipeline run timestamp (shared across job)
  run_id            STRING,      -- pipeline run id (shared across job)
  gold_last_run_ts  TIMESTAMP,   -- max(gold_run_ts) in the source table
  gold_last_ingest  TIMESTAMP,   -- max(gold_ingest_ts) in the source table
  gold_row_count    BIGINT,      -- number of rows in source at refresh time
  note              STRING       -- freeform comments if I need them
) USING DELTA
COMMENT 'Audit log of BI view refresh events for governance and SLA tracking.'
""")

# Grab some quick source stats for the audit row (kept lightweight)
df_gold = spark.read.table(GOLD_TABLE)
gold_max = df_gold.agg(
    F.max("gold_run_ts").alias("max_run_ts"),
    F.max("gold_ingest_ts").alias("max_ingest_ts")
).collect()[0]
gold_last_run_ts = gold_max["max_run_ts"]
gold_last_ingest = gold_max["max_ingest_ts"]
gold_row_count   = df_gold.count()

# Who/where info (Unity Catalog helpful for lineage)
who            = spark.sql("SELECT current_user()").collect()[0][0]
cur_catalog    = spark.sql("SELECT current_catalog()").collect()[0][0]
cur_schema     = spark.sql("SELECT current_schema()").collect()[0][0]
now_ts         = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

# Append one audit record for this refresh
audit_df = spark.createDataFrame([(
    BI_VIEW,                        # bi_view_name
    now_ts,                         # created_ts (string fine; Spark will cast)
    datetime.utcnow().date(),       # created_date
    who,                            # created_by
    GOLD_TABLE,                     # source_table
    cur_catalog,                    # source_catalog
    cur_schema,                     # source_schema
    RUN_TS,                         # run_ts (pipeline)
    RUN_ID,                         # run_id (pipeline)
    gold_last_run_ts,               # gold_last_run_ts
    gold_last_ingest,               # gold_last_ingest
    int(gold_row_count),            # gold_row_count
    "BI view refreshed from job"    # note
)], schema="""
  bi_view_name STRING,
  created_ts   STRING,
  created_date DATE,
  created_by   STRING,
  source_table STRING,
  source_catalog STRING,
  source_schema  STRING,
  run_ts STRING,
  run_id STRING,
  gold_last_run_ts TIMESTAMP,
  gold_last_ingest TIMESTAMP,
  gold_row_count BIGINT,
  note STRING
""")

audit_df.write.mode("append").saveAsTable(AUDIT_TABLE)

print(f"✅ BI view refreshed → {BI_VIEW}")
print(f"🧾 Audit appended   → {AUDIT_TABLE}")
print(f"   gold_row_count={gold_row_count:,}  gold_last_run_ts={gold_last_run_ts}  run_id={RUN_ID}")


# COMMAND ----------

# ============================================================
# GOLD VALIDATION — fact & KPI quality checks
# Author: Vedanti Awaghade
#
# What I’m checking:
#  0) Tables/views exist (Silver, Gold, BI view)
#  1) Freshness (gold_ingest_ts) and basic row count
#  2) Required columns present (measures + KPIs)
#  3) KPI sanity/bounds (>=0, ratios in [0,1], no NaN/Inf)
#  4) Recompute from Silver and reconcile with Gold (within tolerance)
#  5) Print a clean summary + alerts
# ============================================================

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta
import json
import math

# ---------------------------
# Config & constants
# ---------------------------
config        = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
CATALOG       = config["catalog"]
SILVER_TABLE  = config["silver_table"]
GOLD_TABLE    = config["gold_table"]
BI_VIEW       = config["bi_view"]

spark.sql(f"USE CATALOG {CATALOG}")

TOL   = 1e-6    # numeric reconciliation tolerance
FRESH = 6       # hours; flag if gold is older than this

# Optional: scope validation to a month or range
# dbutils.widgets.text("month_filter", "")     # e.g., "2023-08-01"
# MONTH_FILTER = dbutils.widgets.get("month_filter").strip()

# ---------------------------
# Helpers
# ---------------------------
def table_exists(name: str) -> bool:
    try:
        return spark.catalog.tableExists(name)
    except Exception:
        return False

def view_exists(name: str) -> bool:
    try:
        spark.table(name)
        return True
    except Exception:
        return False

def ratio_in_01(col):
    return (F.col(col) >= 0) & (F.col(col) <= 1)

# ---------------------------
# 0) Existence
# ---------------------------
issues = []
if not table_exists(SILVER_TABLE): issues.append(f"Missing Silver: {SILVER_TABLE}")
if not table_exists(GOLD_TABLE):   issues.append(f"Missing Gold: {GOLD_TABLE}")
if not view_exists(BI_VIEW):       issues.append(f"Missing BI view: {BI_VIEW}")

if issues:
    print("❌ Validation halted — required object(s) missing:")
    for i in issues: print("  •", i)
    raise SystemExit

# ---------------------------
# Load data (optionally filter by month)
# ---------------------------
dfs = spark.read.table(SILVER_TABLE)
dfg = spark.read.table(GOLD_TABLE)

# if MONTH_FILTER:
#     dfs = dfs.filter(F.col("month") == F.to_date(F.lit(MONTH_FILTER)))
#     dfg = dfg.filter(F.col("month") == F.to_date(F.lit(MONTH_FILTER)))

# ---------------------------
# 1) Freshness & counts
# ---------------------------
gold_cnt = dfg.count()
max_g_ts = dfg.agg(F.max("gold_ingest_ts")).first()[0]
fresh_min = None
if max_g_ts:
    fresh_min = (datetime.utcnow() - max_g_ts.replace(tzinfo=None)).total_seconds()/60

print(f"Gold rows: {gold_cnt:,}")
print(f"Gold max(gold_ingest_ts): {max_g_ts}  (~{round(fresh_min,1) if fresh_min is not None else 'NA'} min ago)")

# ---------------------------
# 2) Required columns
# ---------------------------
req_measures = {
    "spend","impressions","clicks","measurable_imps","viewable_imps",
    "engagements","video_start","video_complete","audio_start","audio_complete"
}
req_kpis = {"cpm","cpe","ctr","viewability","engagement_rate","vcr","acr","gold_ingest_ts","gold_run_ts"}
req_dims = {"month","format","device_type","bid_type","network_id"}

missing_cols = (req_measures | req_kpis | req_dims) - set(dfg.columns)
if missing_cols:
    issues.append(f"Gold missing columns: {sorted(missing_cols)}")

# ---------------------------
# 3) KPI sanity checks
# ---------------------------
kpi_bounds = {
    "cpm": (0, None),           # >= 0
    "cpe": (0, None),           # >= 0 (can be None if engagements = 0)
    "ctr": (0, 1),              # [0,1]
    "viewability": (0, 1),      # [0,1]
    "engagement_rate": (0, None),  # >= 0 (can exceed 1 if engagements>clicks in some defs; we just require non-negative)
    "vcr": (0, 1),              # [0,1]
    "acr": (0, 1)               # [0,1]
}
kpi_violations = {}
for k, (lo, hi) in kpi_bounds.items():
    if k in dfg.columns:
        cond = (F.col(k) < lo) | (F.isnan(k)) | (F.col(k).isNull())
        if hi is not None:
            cond = cond | (F.col(k) > hi)
        cnt = dfg.filter(cond).count()
        if cnt > 0:
            kpi_violations[k] = cnt

# ---------------------------
# 4) Recompute from Silver and reconcile with Gold
# ---------------------------
grain = ["month","format","device_type","bid_type","network_id"]

# Sum Silver to the Gold grain
dfs_agg = (
    dfs.groupBy(grain)
       .agg(
           F.sum("spend").alias("spend"),
           F.sum("impressions").alias("impressions"),
           F.sum("clicks").alias("clicks"),
           F.sum("measurable_imps").alias("measurable_imps"),
           F.sum("viewable_imps").alias("viewable_imps"),
           F.sum("engagements").alias("engagements"),
           F.sum("video_start").alias("video_start"),
           F.sum("video_complete").alias("video_complete"),
           F.sum("audio_start").alias("audio_start"),
           F.sum("audio_complete").alias("audio_complete")
       )
)

# Compute KPIs safely (same formulas as Gold)
def safe_div(n, d):
    return F.when((d.isNull()) | (d == 0), F.lit(None).cast("double")).otherwise(n / d)

dfs_chk = (
    dfs_agg
      .withColumn("cpm",  safe_div(F.col("spend"), F.col("impressions")) * F.lit(1000.0))
      .withColumn("cpe",  safe_div(F.col("spend"), F.col("engagements")))
      .withColumn("ctr",  safe_div(F.col("clicks"), F.col("impressions")))
      .withColumn("viewability",     safe_div(F.col("viewable_imps"), F.col("measurable_imps")))
      .withColumn("engagement_rate", safe_div(F.col("engagements"), F.col("clicks")))
      .withColumn("vcr",  safe_div(F.col("video_complete"), F.col("video_start")))
      .withColumn("acr",  safe_div(F.col("audio_complete"), F.col("audio_start")))
)

# Join with Gold and compare numeric columns
join_cols = grain
compare_cols = list(req_measures | {"cpm","cpe","ctr","viewability","engagement_rate","vcr","acr"})
present = [c for c in compare_cols if c in dfg.columns and c in dfs_chk.columns]

df_join = (
    dfg.alias("g").join(dfs_chk.alias("s"), on=join_cols, how="full")
)

# For each numeric col, compute abs diff and flag above tolerance
recon = {}
for c in present:
    diff_col = F.abs(F.col(f"g.{c}") - F.col(f"s.{c}"))
    cnt_over = df_join.filter(diff_col > TOL).count()
    if cnt_over > 0:
        recon[c] = cnt_over

# Also check for unmatched keys (present in one side but not the other)
only_gold = df_join.filter(
    F.col("g.month").isNotNull() & F.col("s.month").isNull()
).count()
only_silver = df_join.filter(
    F.col("s.month").isNotNull() & F.col("g.month").isNull()
).count()

# ---------------------------
# 5) Summary + Alerts
# ---------------------------
print("\n=== GOLD VALIDATION SUMMARY ==========================")
print(f"• Missing columns          : {sorted(missing_cols) if missing_cols else 'None'}")
print(f"• KPI bound violations     : {kpi_violations if kpi_violations else 'None'}")
print(f"• Unmatched keys           : only_gold={only_gold:,}, only_silver={only_silver:,}")
print(f"• Reconciliation diffs (> {TOL}): {recon if recon else 'None'}")

alerts = []
if fresh_min is not None and fresh_min > FRESH*60:
    alerts.append(f"Gold looks stale (> {FRESH}h): ~{round(fresh_min/60,2)}h")
if missing_cols:
    alerts.append("Gold is missing required columns.")
if kpi_violations:
    alerts.append("Some KPIs are out of expected bounds or null/NaN.")
if only_gold or only_silver:
    alerts.append("Gold/Silver have unmatched groups at the reporting grain.")
if recon:
    alerts.append("Gold and recomputed-from-Silver don’t match within tolerance.")

if alerts:
    print("\n⚠️  ALERTS:")
    for a in alerts:
        print("   •", a)
else:
    print("\n✅ Gold validation passed the main checks.")

# ---------------------------
# Optional: show a few suspect rows for any recon diff
# ---------------------------
if recon or only_gold or only_silver:
    suspect_cols = [c for c, n in recon.items() if n > 0]
    show_cols = grain + suspect_cols
    print("\nExample suspect rows (first 20):")
    display(
        df_join
          .select(*( [F.col(f"g.{c}").alias(c) for c in show_cols] +
                     [F.col(f"s.{c}").alias(f"{c}_recalc") for c in suspect_cols] ))
          .where(
              (F.col("g.month").isNull()) | (F.col("s.month").isNull()) |
              F.lit(True).isin([False])  # placeholder to allow OR’ing diffs below
          )
          .limit(20)
    )


# COMMAND ----------

# Inspect KPIs that triggered the alert
suspect_kpis = ["cpm", "cpe", "ctr", "viewability", "engagement_rate", "vcr", "acr"]

for kpi in suspect_kpis:
    if kpi in dfg.columns:
        df_invalid = (
            dfg.filter(
                (F.isnan(F.col(kpi))) |
                (F.col(kpi).isNull()) |
                (F.col(kpi) < 0) |
                (F.col(kpi) > 1)   # applies only to ratio-type metrics
            )
        )
        count = df_invalid.count()
        if count > 0:
            print(f"⚠️ {kpi}: {count} invalid values")
            display(df_invalid.limit(10))
