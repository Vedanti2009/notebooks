# Databricks notebook source
# ---- shared run stamp (robust to missing controller) ----
from datetime import datetime

def ensure_run_conf():
    # 1) allow passing via Databricks Job param
    try:
        import re
        run_ts_widget = dbutils.widgets.get("run_ts")  # widget optional
    except Exception:
        run_ts_widget = ""

    if run_ts_widget:
        run_ts = run_ts_widget
        run_id = re.sub(r"[-: T]", "", run_ts)[:14]  # compact yyyyMMddHHmmss
    else:
        # 2) try existing spark conf set by controller
        try:
            run_ts = spark.conf.get("dsp.run_ts")
            run_id = spark.conf.get("dsp.run_id")
        except Exception:
            # 3) fallback: generate now, and set it so downstream notebooks see it
            run_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
            spark.conf.set("dsp.run_ts", run_ts)
            spark.conf.set("dsp.run_id", run_id)
    return run_ts, run_id

RUN_TS_STR, RUN_ID = ensure_run_conf()
print(f"RUN_TS={RUN_TS_STR}  RUN_ID={RUN_ID}")


# COMMAND ----------

# ============================================================
# 01_bronze — UC-safe Auto Loader with PK + lineage
# keeps raw strings (no early coercion), deterministic PK,
# and stamps source + ingest times. After write, purge to keep only this run.
# ============================================================
from pyspark.sql import functions as F
import json

config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
incoming_path = config["incoming_path"]
bronze_table  = config["bronze_table"]
bronze_ckpt   = config.get("bronze_checkpoint","dbfs:/chkpt/dsp/bronze")
schema_loc    = "dbfs:/chkpt/dsp/schema"
catalog       = config["catalog"]

# consistent run stamp from controller
RUN_TS_STR = spark.conf.get("dsp.run_ts")

# be in correct catalog
cur = spark.sql("SELECT current_catalog()").collect()[0][0]
if cur != catalog:
    spark.sql(f"USE CATALOG {catalog}")

# ensure Bronze exists with audit/PK; new columns can merge-schema during write
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {bronze_table} (
  -- raw columns will be merged in on first write
  record_id STRING,
  bronze_ingest_ts TIMESTAMP,
  bronze_source_file STRING,
  bronze_source_system STRING,
  load_date DATE,
  load_timestamp STRING
) USING DELTA
""")

# read CSVs as raw strings for stable hashing + full fidelity
df = (spark.readStream
          .format("cloudFiles")
          .option("cloudFiles.format", "csv")
          .option("cloudFiles.inferColumnTypes", "false")    # keep raw text
          .option("cloudFiles.schemaLocation", schema_loc)
          .option("cloudFiles.includeExistingFiles", "true")
          .load(incoming_path)
          .withColumn("bronze_source_file", F.col("_metadata.file_path"))
          .withColumn("bronze_source_system", F.lit(config["gcs_bucket"]))
          .withColumn("bronze_ingest_ts", F.current_timestamp())
          .withColumn("load_timestamp", F.lit(RUN_TS_STR))
          .withColumn("load_date", F.current_date())
)

# trim headers but keep values as strings
df = df.select([F.col(c).alias(c.strip()) for c in df.columns])

# deterministic PK from raw columns + source_file (exclude audit/meta cols)
audit_cols = {"record_id","bronze_ingest_ts","bronze_source_file","bronze_source_system","load_date","load_timestamp","_metadata"}
raw_cols = [c for c in df.columns if c not in audit_cols]
raw_cols_sorted = sorted(raw_cols)
df = df.withColumn(
    "record_id",
    F.sha2(F.concat_ws("§", *[F.coalesce(F.col(c).cast("string"), F.lit("")) for c in raw_cols_sorted],
                       F.coalesce(F.col("bronze_source_file"), F.lit(""))), 256)
)

# write once (batch-like) and merge schema
q = (df.writeStream
        .format("delta")
        .option("checkpointLocation", bronze_ckpt)
        .option("mergeSchema","true")
        .outputMode("append")
        .trigger(availableNow=True)
        .toTable(bronze_table))
q.awaitTermination()

# keep only this run in Bronze
from datetime import datetime  # (already imported above is fine)
def purge_to_current_run(table_name:str, ts_col:str, run_ts:str):
    cols = [r.col_name.lower() for r in spark.sql(f"DESCRIBE {table_name}").select("col_name").collect()]
    if ts_col.lower() not in cols:
        spark.sql(f"ALTER TABLE {table_name} ADD COLUMNS ({ts_col} STRING)")
    spark.sql(f"DELETE FROM {table_name} WHERE {ts_col} IS NULL OR {ts_col} <> '{run_ts}'")
    print(f"[purge] {table_name} retained latest run only.")

purge_to_current_run(bronze_table, "load_timestamp", RUN_TS_STR)

print("bronze ✅ latest-only")


# COMMAND ----------

# MAGIC %md
# MAGIC # One-shot Auto Loader run; reprocess everything present now
# MAGIC from pyspark.sql import functions as F
# MAGIC from datetime import datetime
# MAGIC import json
# MAGIC
# MAGIC config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
# MAGIC incoming_path = config["incoming_path"]
# MAGIC bronze_table  = config["bronze_table"]
# MAGIC bronze_ckpt   = config.get("bronze_checkpoint","dbfs:/chkpt/dsp/bronze")
# MAGIC schema_loc    = "dbfs:/chkpt/dsp/schema"
# MAGIC load_ts       = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# MAGIC
# MAGIC # (Re)create audit cols if missing
# MAGIC spark.sql(f"""
# MAGIC CREATE TABLE IF NOT EXISTS {bronze_table} (
# MAGIC   month DATE, format STRING, device_type STRING, bid_type STRING, network_id STRING,
# MAGIC   spend DOUBLE, impressions DOUBLE, clicks DOUBLE, measurable_imps DOUBLE, viewable_imps DOUBLE,
# MAGIC   engagements DOUBLE, video_start DOUBLE, video_complete DOUBLE, audio_start DOUBLE, audio_complete DOUBLE,
# MAGIC   source_file STRING, load_date DATE, load_timestamp STRING
# MAGIC ) USING DELTA
# MAGIC """)
# MAGIC existing = {r.col_name.lower() for r in spark.sql(f"DESCRIBE {bronze_table}").select("col_name").collect()}
# MAGIC adds = []
# MAGIC if "source_file" not in existing:  adds.append("source_file STRING")
# MAGIC if "load_date" not in existing:    adds.append("load_date DATE")
# MAGIC if "load_timestamp" not in existing: adds.append("load_timestamp STRING")
# MAGIC if adds: spark.sql(f"ALTER TABLE {bronze_table} ADD COLUMNS ({', '.join(adds)})")
# MAGIC
# MAGIC bronze_df = (
# MAGIC     spark.readStream
# MAGIC          .format("cloudFiles")
# MAGIC          .option("cloudFiles.format", "csv")
# MAGIC          .option("cloudFiles.inferColumnTypes", "true")
# MAGIC          .option("cloudFiles.schemaLocation", schema_loc)
# MAGIC          .option("cloudFiles.includeExistingFiles", "true")   # load what’s already there
# MAGIC          .load(incoming_path)
# MAGIC          .withColumn("source_file", F.col("_metadata.file_path"))  # UC-safe file path
# MAGIC          .withColumn("load_timestamp", F.lit(load_ts))
# MAGIC          .withColumn("load_date", F.current_date())
# MAGIC )
# MAGIC bronze_df = bronze_df.select([F.col(c).alias(c.strip()) for c in bronze_df.columns])
# MAGIC
# MAGIC q = (bronze_df.writeStream
# MAGIC      .format("delta")
# MAGIC      .option("checkpointLocation", bronze_ckpt)
# MAGIC      .option("mergeSchema", "true")
# MAGIC      .outputMode("append")
# MAGIC      .trigger(availableNow=True)     # batch-like single run
# MAGIC      .toTable(bronze_table))
# MAGIC q.awaitTermination()
# MAGIC
# MAGIC # quick check
# MAGIC display(spark.table(bronze_table).orderBy(F.desc("load_timestamp")).limit(20))
# MAGIC

# COMMAND ----------

# ============================
# BRONZE — LIVE VALIDATION
# ============================
from pyspark.sql import functions as F
import json

# Config + helpers
config = json.load(open("/Workspace/Repos/dsp_etl_project/configs/etl_config.json"))
bronze_table = config["bronze_table"]        # e.g., mars.raw.dsp_bronze

print(f"Checking table: {bronze_table}")

# 1) Exists? basic stats
spark.sql(f"DESCRIBE TABLE {bronze_table}").show(truncate=False)

rows = spark.table(bronze_table).count()
cols = len(spark.table(bronze_table).columns)
print(f"Total Rows: {rows:,} | Total Columns: {cols}")

# 2) Top sample (newest first if audit cols exist)
df = spark.table(bronze_table)
if "load_timestamp" in [c.lower() for c in df.columns]:
    display(df.orderBy(F.desc("load_timestamp")).limit(20))
else:
    display(df.limit(20))

# 3) Schema
df.printSchema()

# 4) Latest batch file list (UC-safe via source_file/_metadata)
if "source_file" in [c.lower() for c in df.columns]:
    print("\nFiles in the latest load (by load_timestamp):")
    latest_ts = df.select("load_timestamp").orderBy(F.desc("load_timestamp")).limit(1).collect()
    if latest_ts:
        latest_ts = latest_ts[0][0]
        (df.filter(F.col("load_timestamp")==latest_ts)
           .select("source_file").distinct().show(truncate=False))
    else:
        print("No load_timestamp found in rows.")
else:
    print("\nNo source_file column present (that’s ok if you didn’t add audit cols).")

# 5) Table history (Delta ops)
print("\nDelta Table History:")
spark.sql(f"DESCRIBE HISTORY {bronze_table}").show(truncate=False)
